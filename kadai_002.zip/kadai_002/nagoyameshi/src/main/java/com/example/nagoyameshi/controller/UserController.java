//会員用コントローラ

package com.example.nagoyameshi.controller;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.PasswordResetToken;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ForgotPasswordForm;
import com.example.nagoyameshi.form.ResetPasswordForm;
import com.example.nagoyameshi.form.UserEditForm;
import com.example.nagoyameshi.repository.PasswordResetTokenRepository;
import com.example.nagoyameshi.repository.UserRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	private final UserRepository userRepository;
	private final UserService userService;
	private final PasswordResetTokenRepository passwordResetTokenRepository;
	private final PasswordEncoder passwordEncoder;

	public UserController(UserRepository userRepository, UserService userService,
			PasswordResetTokenRepository passwordResetTokenRepository,
			PasswordEncoder passwordEncoder) {
		this.userRepository = userRepository;
		this.userService = userService;
		this.passwordResetTokenRepository = passwordResetTokenRepository;
		this.passwordEncoder = passwordEncoder;

	}

	//会員情報ページ取得
	@GetMapping
	public String index(@AuthenticationPrincipal UserDetailsImpl userDetailsImpl, Model model) {
		
		//ログインユーザーのIDを取得
		User user = userRepository.getReferenceById(userDetailsImpl.getUser().getId());

		model.addAttribute("user", user);

		return "user/index";
	}

	//会員情報変更フォーム取得
	@GetMapping("/edit")
	public String edit(@AuthenticationPrincipal UserDetailsImpl userDetailsImpl, Model model) {
		
		//ログインユーザーのIDを取得
		User user = userRepository.getReferenceById(userDetailsImpl.getUser().getId());
		//userのデータを保持してフォームを生成
		UserEditForm userEditForm = new UserEditForm(user.getId(), user.getUserName(), user.getFurigana(),
				user.getPostalCode(), user.getAddress(), user.getPhoneNumber(), user.getEmail());

		model.addAttribute("userEditForm", userEditForm);

		return "user/edit";
	}

	//変更した会員情報の登録
	@PostMapping("/update")
	public String update(@ModelAttribute @Validated UserEditForm userEditForm, BindingResult bindingResult,
			RedirectAttributes redirectAttributes) {
		
		// メールアドレスが変更されており、かつ登録済みであれば、BindingResultオブジェクトにエラー内容を追加する
		if (userService.isEmailChanged(userEditForm) && userService.isEmailRegistered(userEditForm.getEmail())) {
			FieldError fieldError = new FieldError(bindingResult.getObjectName(), "email", "すでに登録済みのメールアドレスです。");
			bindingResult.addError(fieldError);
		}

		if (bindingResult.hasErrors()) {
			return "user/edit";
		}

		//更新メソッドを呼び出し、更新
		userService.update(userEditForm);
		
		redirectAttributes.addFlashAttribute("successMessage", "会員情報を編集しました。");
		
		return "redirect:/user";
	}

	//パスワード再設定URL送信用メールフォームの取得
	@GetMapping("/forgotpassword")
	private String forgotPassword(Model model) {

		model.addAttribute("forgotPasswordForm", new ForgotPasswordForm());

		return "user/forgotpassword";
	}

	//パスワード再設定用URL送信
	@PostMapping("/forgotpassword")
	public String processForgotPassword(
			@ModelAttribute("forgotPasswordForm") @Validated ForgotPasswordForm forgotPasswordForm,
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes,
			Model model) {

		if (bindingResult.hasErrors()) {
			return "user/forgotpassword";
		}

		//フォームからメールアドレスを取得
		String email = forgotPasswordForm.getEmail();
		//userエンティティに存在するメールアドレスを取得
		User user = userRepository.findByEmail(email);
		
		//メールアドレスが存在しない場合
		if (user == null) {
			model.addAttribute("error", "メールアドレスが見つかりません。");
			return "user/forgotpassword";
		}

		//パスワードリセット用トークンを生成
		String token = UUID.randomUUID().toString();

		//ユーザーのトークンを取得
		PasswordResetToken existingToken = passwordResetTokenRepository.findByUser(user);
		//トークンが存在すれば
		if (existingToken != null) {
			existingToken.setToken(token);
			existingToken.setCreatedAt(Timestamp.from(Instant.now()));
			passwordResetTokenRepository.save(existingToken);
		} else {
			PasswordResetToken resetToken = new PasswordResetToken();
			resetToken.setToken(token);
			resetToken.setUser(user);
			resetToken.setCreatedAt(Timestamp.from(Instant.now()));
			passwordResetTokenRepository.save(resetToken);
		}

		//メール添付URL
		String resetLink = "http://localhost:8080/user/resetpassword?token=" + token;
		//メール送信メソッドを呼び出し、送信
		userService.sendPasswordResetEmail(user.getEmail(), resetLink);

		redirectAttributes.addFlashAttribute("successMessage", "パスワード再設定用メールを送信しました。"
				+ "メールが届かない場合はメールアドレスや受信設定をご確認ください。");

		return "redirect:/user/forgotpassword";
	}

	//パスワード再設定フォームの取得
	@GetMapping("/resetpassword")
	private String resetPassword(@RequestParam("token") String token, Model model) {

		model.addAttribute("resetPasswordForm", new ResetPasswordForm());
		model.addAttribute("token", token);

		return "user/resetpassword";
	}

	//再設定するパスワードの登録
	@PostMapping("/resetpassword")
	public String resetPassword(@RequestParam("token") String token,
			@ModelAttribute ResetPasswordForm resetPasswordForm,
			RedirectAttributes redirectAttributes, Model model) {

		//全ユーザーを取得
		List<User> allUsers = userRepository.findAll();
		//フォームから新たに設定するパスワードを取得
		String newPassword = resetPasswordForm.getNewPassword();
		////フォームから新たに設定するパスワードの確認用を取得
		String newPasswordConfirmation = resetPasswordForm.getNewPasswordConfirmation();
		//トークンを取得
		PasswordResetToken resetToken = passwordResetTokenRepository.findByToken(token);

		//全ユーザーをループ処理
		for (User users : allUsers) {
			//新たなパスワードを既に他のユーザーが使用していた場合
			if (passwordEncoder.matches(newPassword, users.getPassword())) {
				model.addAttribute("error", "このパスワードはすでに使用されています。他のパスワードを設定してください。");
				model.addAttribute("token", token);
				model.addAttribute("resetPasswordForm", new ResetPasswordForm());

				return "user/resetpassword";
			}
		}
		//新たなパスワードと確認用パスワードが一致しない場合
		if (!newPassword.equals(newPasswordConfirmation)) {
			model.addAttribute("error", "パスワードが一致しません");
			model.addAttribute("token", token);
			model.addAttribute("resetPasswordForm", new ResetPasswordForm());

			return "user/resetpassword";
		}
		//トークンが無効であれば
		if (resetToken == null || resetToken.isExpired()) {
			model.addAttribute("error", "無効または期限切れのトークンです");
			model.addAttribute("resetPasswordForm", new ResetPasswordForm());

			return "user/resetpassword";
		}
		
		//トークンに紐づくユーザーを取得
		User user = resetToken.getUser();
		
		//userエンティティにパスワードをセットしセーブ
		user.setPassword(passwordEncoder.encode(newPassword));
		userRepository.save(user);
		
		//トークンを削除
		passwordResetTokenRepository.delete(resetToken);

		redirectAttributes.addFlashAttribute("successMessage", "パスワードを変更しました。");

		return "redirect:/";

	}
}
