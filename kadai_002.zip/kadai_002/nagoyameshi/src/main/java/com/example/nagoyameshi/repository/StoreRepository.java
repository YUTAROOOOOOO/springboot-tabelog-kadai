package com.example.nagoyameshi.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.example.nagoyameshi.entity.Store;
public interface StoreRepository extends JpaRepository<Store, Integer>, JpaSpecificationExecutor<Store> {


	Page<Store> findAll(Specification<Store> spec, Pageable sortedPageable);

	Page<Store> findByStoreNameContaining(String keyword, Pageable pageable);

	Page<Store> findByMaxBudgetLessThanEqual(Integer maxBudget, Pageable pageable);

	Page<Store> findByStoreNameLike(String string, Pageable pageable);

	List<Store> findTop5ByOrderByCreatedAtDesc();

}

