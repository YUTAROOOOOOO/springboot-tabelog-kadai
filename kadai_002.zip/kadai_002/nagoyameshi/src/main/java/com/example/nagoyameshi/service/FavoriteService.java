package com.example.nagoyameshi.service;

import java.sql.Timestamp;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.nagoyameshi.entity.Favorite;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.repository.FavoriteRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;

@Service
public class FavoriteService {
    private final FavoriteRepository favoriteRepository;
	private final UserRepository userRepository;
	private final StoreRepository storeRepository;

    public FavoriteService(FavoriteRepository favoriteRepository, UserRepository userRepository,
			StoreRepository storeRepository) {
		this.favoriteRepository = favoriteRepository;
		this.userRepository = userRepository;
		this.storeRepository = storeRepository;
    }
    
    //お気に入り登録処理
    @Transactional
    public void createFavorite(Integer userId, Integer storeId) {
        // 重複チェック（既に登録済みなら何もしない）
        if (favoriteRepository.existsByUserIdAndStoreId(userId, storeId)) return;

        User user = userRepository.getReferenceById(userId);
        Store store = storeRepository.getReferenceById(storeId);

        Favorite favorite = new Favorite();
        favorite.setUser(user);
        favorite.setStore(store);
        favorite.setCreatedAt(new Timestamp(System.currentTimeMillis()));

        favoriteRepository.save(favorite);
    }

    //お気に入り解除
    @Transactional
    public void removeFavorite(Integer userId, Integer storeId) {
        favoriteRepository.deleteByUserIdAndStoreId(userId, storeId);
    }

    //ユーザーがお気に入り済みかを判定
    @Transactional
    public boolean isFavorited(Integer userId, Integer storeId) {
        return favoriteRepository.existsByUserIdAndStoreId(userId, storeId);
    }

}
