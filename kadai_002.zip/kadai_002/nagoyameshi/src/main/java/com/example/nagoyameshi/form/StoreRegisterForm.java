//店舗登録フォーム

package com.example.nagoyameshi.form;

import java.time.LocalTime;
import java.util.List;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

import com.example.nagoyameshi.entity.Category;

import lombok.Data;

@Data
public class StoreRegisterForm {
	
	@NotNull(message = "カテゴリーを選択して下さい。")
	private Category category;
	
	@NotBlank(message = "店舗名を入力して下さい。")
	private String storeName;
	
	private MultipartFile imageFile;
	
	@NotBlank(message = "説明を入力して下さい。")
	private String description;
	
	@NotNull(message = "定員を入力して下さい。")
	@Min(value = 1, message = "定員は1人以上に設定して下さい。")
	private Integer capacity;
	
	@NotNull(message = "予算下限を入力して下さい。")
	@Min(value = 1, message = "予算は1円以上に設定して下さい。")
	private Integer minBudget;
	
	@NotNull(message = "予算上限を入力して下さい。")
	@Min(value = 1, message = "予算は1円以上に設定して下さい。")
	private Integer maxBudget;
	
	@NotNull(message = "営業開始時間を入力して下さい。")
	private LocalTime openingTime;
	
	@NotNull(message = "営業終了時間を入力して下さい。")
	private LocalTime closingTime;
	
	@NotNull(message = "定休日を選択して下さい。")
	private List<String> regularHoliday;
	
	@NotBlank(message = "郵便番号を入力して下さい。")
	private String postalCode;
	
	@NotBlank(message = "住所を入力して下さい。")
	private String address;
	
	@NotBlank(message = "電話番号を入力して下さい。")
	private String phoneNumber;

}
