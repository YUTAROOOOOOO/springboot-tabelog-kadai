package com.example.nagoyameshi.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.service.ReservationService;

@Controller
public class SpringController {

	private final ReservationService reservationService;

	public SpringController(ReservationService reservationService) {

		this.reservationService = reservationService;
	}

	@GetMapping("/stores/{storeId}/reservation/times")
	@ResponseBody
	public List<String> getTimeSlots(@PathVariable Integer storeId,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate reservationDate,
			@RequestParam Integer numberOfPeople) {
		
		//予約フォームを生成
		ReservationInputForm reservationInputForm = new ReservationInputForm();
		
		//予約フォームのデータをエンティティにセット
		reservationInputForm.setReservationDate(reservationDate);
		reservationInputForm.setNumberOfPeople(numberOfPeople);

		return reservationService.getAvailableTimeSlots(storeId, reservationInputForm)
				.stream()
				.map(LocalTime::toString)
				.collect(Collectors.toList());
	}
}