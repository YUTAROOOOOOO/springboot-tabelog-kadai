package com.example.nagoyameshi.service;

import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.form.ReservationRegisterForm;
import com.example.nagoyameshi.repository.ReservationRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.repository.UserRepository;

@Service
public class ReservationService {

	private final ReservationRepository reservationRepository;
	private final StoreRepository storeRepository;
	private final UserRepository userRepository;

	public ReservationService(ReservationRepository reservationRepository, StoreRepository storeRepository,
			UserRepository userRepository) {
		this.reservationRepository = reservationRepository;
		this.storeRepository = storeRepository;
		this.userRepository = userRepository;
	}

	//定休日以外、空き時間の取得
	public List<LocalTime> getAvailableTimeSlots(Integer storeId, ReservationInputForm form) {
		Store store = storeRepository.getReferenceById(storeId);
		LocalDate date = form.getReservationDate();
		int people = form.getNumberOfPeople();
		String regularHoliday = store.getRegularHoliday();
		
		// 年中無休や不定休は休日とみなさない（全日営業）
		if (regularHoliday != null && 
			(regularHoliday.equals("年中無休") || regularHoliday.equals("不定休"))) {
			regularHoliday = ""; // 空文字にして定休日チェックをスキップ
		}

		// String型の文字列を「,」で分割
		List<String> holidays = Arrays.asList(regularHoliday.split(","));

		// 2. 予約日と曜日
		DayOfWeek selectedDay = date.getDayOfWeek();

		// 3. 定休日との照合
		for (String holiday : holidays) {
			if (holiday.isBlank()) continue; // ← 空文字チェック追加
			int holidayIndex = getDayOfWeekIndex(holiday.trim());
			if (holidayIndex == selectedDay.getValue()) {
				return Collections.emptyList();
			}
		}

		// 4. 営業時間
		LocalTime open = store.getOpeningTime();
		LocalTime close = store.getClosingTime();

		// 5. 空き時間の判定
		List<LocalTime> available = new ArrayList<>();
		for (LocalTime time = open;; time = time.plusMinutes(30)) {
			if (!isTimeWithinBusinessHours(time, open, close)) {
				break;
			}

			int reserved = reservationRepository.countReservedNumberOfPeopleByStoreAndTime(storeId, date, time);
			if (reserved + people <= store.getCapacity()) {
				available.add(time);
			}
		}

		return available;
	}

	//営業時間の取得
	private boolean isTimeWithinBusinessHours(LocalTime time, LocalTime open, LocalTime close) {
		if (close.isBefore(open)) {
			return !time.isBefore(open) || !time.isAfter(close); // 深夜営業
		} else {
			return !time.isBefore(open) && time.isBefore(close); // 通常営業
		}
	}

	private int getDayOfWeekIndex(String jpDay) {
		switch (jpDay) {
		case "月":
			return 1;
		case "火":
			return 2;
		case "水":
			return 3;
		case "木":
			return 4;
		case "金":
			return 5;
		case "土":
			return 6;
		case "日":
			return 7;
		default:
			throw new IllegalArgumentException("不明な曜日: " + jpDay);
		}
	}

	@Transactional
	public void create(ReservationRegisterForm reservationRegisterForm, Integer storeId, Integer userId) {

		// 店舗を取得  
		Store store = storeRepository.getReferenceById(storeId);
		// ユーザーを取得
		User user = userRepository.getReferenceById(userId);

		Reservation reservation = new Reservation();

		reservation.setStore(store);
		reservation.setUser(user);
		reservation.setReservationDate(reservationRegisterForm.getReservationDate());
		reservation.setReservationTime(reservationRegisterForm.getReservationTime());
		reservation.setNumberOfPeople(reservationRegisterForm.getNumberOfPeople());
		reservation.setCreatedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		reservationRepository.save(reservation);
	}

	//予約人数が定員以下かどうかをチェックする
	public boolean isWithinCapacity(Integer numberOfPeople, Integer capacity) {
		return numberOfPeople <= capacity;
	}
}
