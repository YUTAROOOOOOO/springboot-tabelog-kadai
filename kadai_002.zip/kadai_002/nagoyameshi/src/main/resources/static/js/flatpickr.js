document.addEventListener("DOMContentLoaded", function() {
	const formElement = document.getElementById("reservationForm");
	const storeId = formElement.dataset.storeId;
	const dateInput = document.getElementById("reservationDate");
	const peopleInput = document.getElementById("numberOfPeople");
	const timeSelect = document.getElementById("reservationTime");
	const submitButton = document.getElementById("submitButton");  // ボタンの取得
	const holidays = dateInput.dataset.holiday?.split(",") || [];

	// ボタンの有効/無効をチェックする関数
	function checkFormValidity() {
		if (dateInput.value && timeSelect.value && peopleInput.value) {
			submitButton.disabled = false;  // すべての入力が完了していればボタンを有効化
		} else {
			submitButton.disabled = true;  // 入力されていない項目があればボタンを無効化
		}
	}

	// イベントリスナーを追加して、フォームの入力内容が変わったときにチェックを実行
	dateInput.addEventListener('change', checkFormValidity);
	timeSelect.addEventListener('change', checkFormValidity);
	peopleInput.addEventListener('input', checkFormValidity);

	// 最初にボタンの状態をチェック
	checkFormValidity();

	const weekdayMap = { '日': 0, '月': 1, '火': 2, '水': 3, '木': 4, '金': 5, '土': 6 };
	const disabledDays = holidays.map(day => weekdayMap[day.trim()]);

	const today = new Date();
	const maxDate = new Date();
	maxDate.setMonth(today.getMonth() + 3);

	flatpickr(dateInput, {
		locale: "ja",
		minDate: "today",
		maxDate: maxDate,
		disable: [date => disabledDays.includes(date.getDay())],
		onChange: updateTimeSlots
	});

	peopleInput.addEventListener("input", updateTimeSlots);

	function updateTimeSlots() {
		const date = dateInput.value;
		const people = peopleInput.value;

		if (!date || !people) {
			// 予約日または予約人数が未入力の場合は時間リストを空にし、ボタンを無効化
			timeSelect.innerHTML = '<option value="">予約日・予約人数を選択してください</option>';
			timeSelect.disabled = true;
			checkFormValidity();  // ボタンの状態を再確認
			return;
		}

		console.log(`fetch開始: /stores/${storeId}/reservation/times?reservationDate=${date}&numberOfPeople=${people}`);

		fetch(`/stores/${storeId}/reservation/times?reservationDate=${date}&numberOfPeople=${people}`)
			.then(res => {
				console.log("レスポンスステータス:", res.status);
				return res.json();
			})
			.then(times => {
				console.log("取得した予約可能時間（times）:", times);

				if (!Array.isArray(times)) {
					console.error("取得データが配列ではありません。times=", times);
					timeSelect.innerHTML = '<option value="">時間取得失敗</option>';
					timeSelect.disabled = true;
					checkFormValidity();  // ボタンの状態を再確認
					return;
				}

				timeSelect.innerHTML = '<option value="">選択してください</option>';
				times.forEach(t => {
					const option = document.createElement("option");
					option.value = t;
					option.textContent = t;
					timeSelect.appendChild(option);
				});
				timeSelect.disabled = false;

				checkFormValidity();  // ボタンの状態を再確認
			})
			.catch(err => {
				console.error("fetchエラー:", err);
				timeSelect.innerHTML = '<option value="">時間取得失敗</option>';
				timeSelect.disabled = true;
				checkFormValidity();  // ボタンの状態を再確認
			});
	}
});