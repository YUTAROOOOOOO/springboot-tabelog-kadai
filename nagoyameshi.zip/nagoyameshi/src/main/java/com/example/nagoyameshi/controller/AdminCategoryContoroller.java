//管理者用店舗管理コントローラ

package com.example.nagoyameshi.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.form.CategoryEditForm;
import com.example.nagoyameshi.form.CategoryRegisterForm;
import com.example.nagoyameshi.repository.CategoryRepository;
import com.example.nagoyameshi.service.CategoryService;

@Controller
public class AdminCategoryContoroller {
	private final CategoryService categoryService;
	private final CategoryRepository categoryRepository;

	public AdminCategoryContoroller(CategoryService categoryService, CategoryRepository categoryRepository) {
		this.categoryService = categoryService;
		this.categoryRepository = categoryRepository;
		
	}

	//カテゴリー一覧ページ
	@GetMapping("/admin/categories")
	public String index(Model model,
			@PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
			@RequestParam(name = "keyword", required = false) String keyword) {
		
		Page<Category> categoryPage;
		
		//カテゴリー名検索
		if (keyword != null && !keyword.isEmpty()) {
			categoryPage = categoryRepository.findByCategoryNameLike("%" + keyword + "%", pageable);
		} else {
			categoryPage = categoryRepository.findAll(pageable);
		}

		model.addAttribute("categoryPage", categoryPage);
		model.addAttribute("keyword", keyword);

		return "admin/categories/index";
	}
	
	//カテゴリー登録ページ
	@GetMapping("/admin/category/register")
	public String register(Model model) {

		model.addAttribute("categoryRegisterForm", new CategoryRegisterForm());
		
		return "admin/categories/register";
	}
	
	//カテゴリー登録
	@PostMapping("/admin/category/create")
	public String create(@ModelAttribute @Validated CategoryRegisterForm categoryRegisterForm, 
			BindingResult bindingResult, RedirectAttributes redirectAttributes, Model model) {
		
		if (bindingResult.hasErrors()) {
			return "admin/stores/register";
		}

		categoryService.create(categoryRegisterForm);
		redirectAttributes.addFlashAttribute("successMessage", "カテゴリーを登録しました。");

		return "redirect:/admin/categories";
	}
	
	//カテゴリー編集ページ
	@GetMapping("/admin/category/{categoryId}/edit")
	public String edit(@PathVariable(name = "categoryId") Integer categoryId, Model model) {
		
		//categoryエンティティのプロキシを取得
		Category category = categoryRepository.getReferenceById(categoryId);
		//categoryのデータを保持してフォームを生成
		CategoryEditForm categoryEditForm = new CategoryEditForm(category.getId(), category.getCategoryName());

		model.addAttribute("categoryEditForm", categoryEditForm);

		return "admin/categories/edit";
	}
	
	//編集した店舗の登録
	@PostMapping("/admin/category/{categoryId}/update")
	public String update(@ModelAttribute @Validated CategoryEditForm categoryEditForm, BindingResult bindingResult,
			RedirectAttributes redirectAttributes) {
		
		if (bindingResult.hasErrors()) {
			return "admin/categories/edit";
		}

		categoryService.update(categoryEditForm);
		redirectAttributes.addFlashAttribute("successMessage", "カテゴリー情報を編集しました。");

		return "redirect:/admin/categories";
	}
	
	//店舗削除
	@PostMapping("/admin/category/{categoryId}/delete")
	public String delete(@PathVariable(name = "categoryId") Integer categoryId, RedirectAttributes redirectAttributes) {
		
		categoryRepository.deleteById(categoryId);

		redirectAttributes.addFlashAttribute("successMessage", "カテゴリーを削除しました。");

		return "redirect:/admin/categories";
	}
}
